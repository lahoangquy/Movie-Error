﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LOGIC.Services.Models.Genre
{
    public class Genre_ResultSet
    {
        public Int64 genre_id { get; set; }
        public String name { get; set; }
    }
}

