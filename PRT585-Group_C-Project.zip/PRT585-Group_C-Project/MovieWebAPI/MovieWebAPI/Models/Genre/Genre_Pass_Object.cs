﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieWebAPI.Models.Movie
{
    public class Genre_Pass_Object
    {
        public Int64 genre_id { get; set; }
        public String name { get; set; }
    }
}
